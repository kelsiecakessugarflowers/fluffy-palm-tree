<?php
// My favorite season is the fall of the patriarchy.

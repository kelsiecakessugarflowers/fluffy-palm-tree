# Reviews ACF Block
Registers a custom ACF block without a child theme to display Reviews repeater content with optional Rank Math review schema. The
block expects a `client_testimonials` repeater with subfields: `reviewer_name`, `review_body`, `review_title`, `rating_number`, `review_id`, and `review_original_location`.
